﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;

namespace MBPS.ProcessingLayer.Web.Models
{
    public class IdentityModel: IPrincipal
    {
        public string UserID { get; set; }
        public IIdentity Identity { get; private set; }

        private string[] _acceptedDomains = new string[]
       {
            "CA",
            "MFCGD",
            "MLIDDOMAIN1",
            "SLAC",
            "PRD"
       };
        public IdentityModel(IIdentity identity)
        {
            try
            {

                var currentUser = HttpContext.Current.User;

                var domainName = identity.Name
                    .Split('\\')[0];

                var UserUid = identity.Name
                    .Split('\\')[1];

                if (_acceptedDomains.Contains(domainName))
                {
                    UserID = UserUid;
                    Identity = identity;
                }
                else
                {
                    Identity = identity;
                }

            }
            catch (Exception ex)
            {
                //context.HttpContext.Response.Redirect("~/Project_Readme.html");
            }

        }

        public bool IsInRole(string role)
        {
            throw new NotImplementedException();
        }
    }
}