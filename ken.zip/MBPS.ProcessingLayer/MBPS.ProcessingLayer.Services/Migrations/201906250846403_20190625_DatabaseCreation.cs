namespace MBPS.ProcessingLayer.Services.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _20190625_DatabaseCreation : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
