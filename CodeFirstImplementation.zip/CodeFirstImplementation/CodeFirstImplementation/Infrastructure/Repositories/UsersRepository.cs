﻿using CodeFirstImplementation.Infrastructure.Database;
using CodeFirstImplementation.Infrastructure.Entities;
using CodeFirstImplementation.Infrastructure.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CodeFirstImplementation.Infrastructure.Repositories
{
    public class UsersRepository : GenericRepository<Users>, IUserRepository
    {
        private readonly DBConfiguration _context;
        public UsersRepository() { }
        public UsersRepository(DBConfiguration context) : base(context) { }
        public List<Users> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        public List<Users> GetById(int id)
        {
            return _context.Users.Where(x => x.Id == id).ToList();
        }

        public IQueryable<Users> GetByIds(int id)
        {
            return _context.Users.Where(x => x.Id == id);
        }
    }
}