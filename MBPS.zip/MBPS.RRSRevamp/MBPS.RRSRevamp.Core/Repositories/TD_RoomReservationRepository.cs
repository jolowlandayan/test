﻿using MBPS.RRSRevamp.Core.Dto;
using MBPS.RRSRevamp.Core.Interfaces;
using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Repositories
{
    public class TD_RoomReservationRepository : GenericRepository<TD_RoomReservation>, ITD_RoomReservationRepository
    {
        public TD_RoomReservationRepository() { }
        public TD_RoomReservationRepository(DataContext Context) : base(Context) { }

        public IEnumerable<MD_Rooms> GetAllAvailableRooms(DateTime startDate, DateTime endDate, int capacity, int buildingId)
        {
            var roomReservationsRepo = Context.TD_RoomReservation;
            var roomReservationList = roomReservationsRepo.Where(x => x.StartDateTime >= startDate && x.EndDateTime <= endDate);

            var availableRooms = Context.MD_Rooms.Where(x => x.BuildingId == buildingId 
                                && !roomReservationList.Any(y => y.RoomId == x.RoomId) 
                                && x.IsActive == true
                                && (x.MinCapacity > capacity
                                || x.MaxCapacity <= capacity)).ToList();

            return availableRooms;
        }
    }
}
