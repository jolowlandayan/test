﻿using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Interfaces
{
    public interface ILkp_FieldTypeRepository : IRepository<Lkp_FieldType>
    {
        IList<Lkp_FieldType> GetAllFieldType();
    }
}
