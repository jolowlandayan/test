﻿using AutoMapper;
using MBPS.ProcessingLayer.Core.Dto.In;
using MBPS.ProcessingLayer.Core.Dto.Out;
using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace MBPS.ProcessingLayer.Services
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            CreateMap();
        }

        private void CreateMap()
        {
            Mapper.CreateMap<RequestInsertCoreActivityDto, MD_CoreActivities>()
                .ForMember(obj => obj.TeamId, dto => dto.MapFrom(x => x.TeamId))
                .ForMember(obj => obj.WorkTypeId, dto => dto.MapFrom(x => x.WorkTypeId))
                .ForMember(obj => obj.CreatedBy, dto => dto.MapFrom(x => x.CreatedBy))
                .ForMember(obj => obj.UpdatedBy, dto => dto.MapFrom(x => x.UpdatedBy));

            Mapper.CreateMap<RequestUpdateCoreActivityDto, MD_CoreActivities>()
                .ForMember(obj => obj.WorkTypeId, dto => dto.MapFrom(x => x.WorkTypeId))
                .ForMember(obj => obj.IsActive, dto => dto.MapFrom(x => x.IsActive))
                .ForMember(obj => obj.UpdatedBy, dto => dto.MapFrom(x => x.UpdatedBy));

            Mapper.CreateMap<MD_CoreActivities_Fields, ResponseCoreActivityFieldsDto>()
                .ForMember(obj => obj.FieldId, dto => dto.MapFrom(x => x.FieldId))
                .ForMember(obj => obj.CoreActivitiesId, dto => dto.MapFrom(x => x.CoreActivitiesId))
                .ForMember(obj => obj.FieldTypeId, dto => dto.MapFrom(x => x.FieldTypeId))
                .ForMember(obj => obj.FieldName, dto => dto.MapFrom(x => x.FieldName))
                .ForMember(obj => obj.CharLimit, dto => dto.MapFrom(x => x.CharLimit))
                .ForMember(obj => obj.IsRequired, dto => dto.MapFrom(x => x.IsRequired));
        }
    }
}
