﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Models
{
    public class Lkp_FieldType
    {
        public int FieldTypeId { get; set; }

        public string FieldType { get; set; }

        public string FieldTypeDescription { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int UpdatedBy { get; set; }

        public DateTime UpdatedDate { get; set; }

    }
}
