﻿using MBPS.ProcessingLayer.Core.Interfaces;
using MBPS.ProcessingLayer.Infrastructure;
using MBPS.ProcessingLayer.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace MBPS.ProcessingLayer.MBPS.ProcessingLayer.Core.UOW
{
    public class UnitOfWork : IUnitOfWork, IDisposable
    {
        private DataContext _context;
        private ILkp_FieldTypeRepository _fieldTypeRepository;
        private IMD_CoreActivities_FieldsRepository _coreActitiviesFieldsRepository;
        private IMD_CoreActivities_Fields_ChoicesRepository _coreActivitiesFieldsChoices;
        private IMD_CoreActivitiesRepository _coreActivitesRepository;

        public UnitOfWork()
        {
            _context = new DataContext();
        }

        public ILkp_FieldTypeRepository FieldTypeRepository()
        {
            if (_fieldTypeRepository == null)
                _fieldTypeRepository = new Lkp_FieldTypeRepository(_context);
            return _fieldTypeRepository;
        }

        public IMD_CoreActivities_FieldsRepository CoreActitiviesFieldsRepository()
        {
            if (_coreActitiviesFieldsRepository == null)
                _coreActitiviesFieldsRepository = new MD_CoreActivities_FieldsRepository(_context);
            return _coreActitiviesFieldsRepository;
        }

        public IMD_CoreActivities_Fields_ChoicesRepository CoreActivitiesFieldsChoicesRepository()
        {
            if (_coreActivitiesFieldsChoices == null)
                _coreActivitiesFieldsChoices = new MD_CoreActivities_Fields_ChoicesRepository(_context);
            return _coreActivitiesFieldsChoices;
        }

        public IMD_CoreActivitiesRepository CoreActivitiesRepository()
        {
            if (_coreActivitesRepository == null)
                _coreActivitesRepository = new MD_CoreActivitiesRepository(_context);
            return _coreActivitesRepository;
        }

        public void Save()
        {
            try
            {
                _context.SaveChanges();
            }
            catch (DbEntityValidationException e)
            {
                var outputLines = new List<string>();
                foreach (var eve in e.EntityValidationErrors)
                {
                    outputLines.Add(string.Format(
                        "{0}: Entity of type \"{1}\" in state \"{2}\" has the following validation errors:", DateTime.Now,
                        eve.Entry.Entity.GetType().Name, eve.Entry.State));
                    foreach (var ve in eve.ValidationErrors)
                    {
                        outputLines.Add(string.Format("- Property: \"{0}\", Error: \"{1}\"", ve.PropertyName, ve.ErrorMessage));
                    }
                }

                throw e;
            }
        }

        private bool disposed = false;
        public virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    Debug.WriteLine("UnitOfWork is being disposed");
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}