﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Core.Models
{
    public class MD_Rooms_Components
    {
        public int RCId { get; set; }

        public int RoomId { get; set; }

        public virtual MD_Rooms MD_Rooms { get; set; }

        public string RCDescription { get; set; }

        public string SerialNumber { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int UpdatedBy { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
