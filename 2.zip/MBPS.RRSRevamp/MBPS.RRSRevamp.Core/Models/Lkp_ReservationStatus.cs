﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Core.Models
{
    public class Lkp_ReservationStatus
    {
        public int ReservationStatusId { get; set; }

        public string ReservationStatusName { get; set; }

        public string ReservationStatusDescription { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int UpdatedBy { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
