﻿using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Core.Dto
{
    public class RoomReservationDto
    {
        public int UserId { get; set; }

        public int RoomId { get; set; }

        public DateTime StartDateTime { get; set; }

        public DateTime EndDateTime { get; set; }

        public string Remarks { get; set; }

        public int ApprovedBy { get; set; }

        public int CreatedBy { get; set; }

        public int UpdatedBy { get; set; }
    }
}
