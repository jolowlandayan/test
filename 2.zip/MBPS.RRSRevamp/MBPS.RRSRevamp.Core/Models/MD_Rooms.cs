﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Core.Models
{
    public class MD_Rooms
    {
        public int RoomId { get; set; }

        public int BuildingId { get; set; }

        public virtual MD_Buildings MD_Buildings { get; set; }

        public string RoomName { get; set; }

        public string RoomDescription { get; set; }

        public int FloorNumber { get; set; }

        public int MinCapacity { get; set; }

        public int MaxCapacity { get; set; }

        public bool IsActive { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int UpdatedBy { get; set; }

        public DateTime UpdatedDate { get; set; }
        
        public IEnumerable<MD_Rooms_Components> RoomComponents { get; set; }
    }
}
