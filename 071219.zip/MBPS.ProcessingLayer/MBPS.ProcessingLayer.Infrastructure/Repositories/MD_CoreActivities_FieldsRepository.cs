﻿using MBPS.ProcessingLayer.Core.Dto.Out;
using MBPS.ProcessingLayer.Core.Interfaces;
using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Infrastructure.Repositories
{
    public class MD_CoreActivities_FieldsRepository : GenericRepository<MD_CoreActivities_Fields>, IMD_CoreActivities_FieldsRepository
    {
        public MD_CoreActivities_FieldsRepository() { }
        public MD_CoreActivities_FieldsRepository(DataContext Context) : base(Context) { }

        public IList<MD_CoreActivities_Fields> GetAllCoreActivityFields()
        {
            var result = Context.MD_CoreActivities_Fields.ToList();
            return result;
        }

        public IList<MD_CoreActivities_Fields> GetCoreActivityFieldsById(int coreactivitiesid)
        {
            var coreActivityFields = Context.MD_CoreActivities_Fields.Where(x => x.CoreActivitiesId == coreactivitiesid).ToList();
            return coreActivityFields;
        }
    }
}
