﻿using MBPS.RRSRevamp.Core.Models;
using MBPS.RRSRevamp.Infrastructure.Configurations;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure
{

    public class DataContext : DbContext
    {
        public virtual DbSet<Lkp_ReservationStatus> Lkp_ReservationStatus { get; set; }
        public virtual DbSet<MD_Buildings> MD_Buildings { get; set; }
        public virtual DbSet<MD_Rooms> MD_Rooms { get; set; }
        public virtual DbSet<MD_Rooms_Components> MD_Rooms_Components { get; set; }
        public virtual DbSet<TD_RoomReservation> TD_RoomReservation { get; set; }

        public DataContext() : base("name=DataContext") { }
        
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new Lkp_ReservationStatusConfiguration());
            modelBuilder.Configurations.Add(new MD_BuildingsConfiguration());
            modelBuilder.Configurations.Add(new MD_Rooms_ComponentsConfiguration());
            modelBuilder.Configurations.Add(new MD_RoomsConfiguration());
            modelBuilder.Configurations.Add(new TD_RoomReservationConfiguration());
            base.OnModelCreating(modelBuilder);
        }

    }
}
