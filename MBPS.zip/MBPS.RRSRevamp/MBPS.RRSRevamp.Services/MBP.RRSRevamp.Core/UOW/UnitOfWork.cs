﻿using MBPS.RRSRevamp.Core.Interfaces;
using MBPS.RRSRevamp.Core.Models;
using MBPS.RRSRevamp.Infrastructure;
using MBPS.RRSRevamp.Infrastructure.Repositories;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Diagnostics;
using System.Linq;
using System.Web;

namespace MBPS.RRSRevamp.Services.MBP.RRSRevamp.Core.UOW
{
    public class UnitOfWork : IUnitOfWork, IDisposable
    {
        private DataContext _context;
        private Lkp_ReservationStatusRepository _reservationStatusRepository;
        private MD_BuildingsRepository _buildingsRepository;
        private MD_RoomsRepository _roomsRepository;
        private MD_RoomsComponentsRepository _roomsComponentRepository;
        private TD_RoomReservationRepository _roomReservationRepository;
        public UnitOfWork()
        {
            _context = new DataContext();
        }
        public Lkp_ReservationStatusRepository ReservationStatusRepository
        {
            get
            {
                if (_reservationStatusRepository == null)
                    _reservationStatusRepository = new Lkp_ReservationStatusRepository(_context);
                return _reservationStatusRepository;
            }
        }

        public MD_BuildingsRepository BuildingsRepository
        {
            get
            {
                if (_buildingsRepository == null)
                    _buildingsRepository = new MD_BuildingsRepository(_context);
                return _buildingsRepository;
            }
        }

        public MD_RoomsRepository RoomsRepository
        {
            get
            {
                if (_roomsRepository == null)
                    _roomsRepository = new MD_RoomsRepository(_context);
                return _roomsRepository;
            }
        }

        public MD_RoomsComponentsRepository RoomsComponentRepository
        {
            get
            {
                if (_roomsComponentRepository == null)
                    _roomsComponentRepository = new MD_RoomsComponentsRepository(_context);
                return _roomsComponentRepository;
            }
        }

        public TD_RoomReservationRepository RoomReservationRepository
        {
            get
            {
                if (_roomReservationRepository == null)
                    _roomReservationRepository = new TD_RoomReservationRepository(_context);
                return _roomReservationRepository;
            }
        }

        public void Save()
        {
            try
            {
                _context.SaveChanges();
            }
            catch (DbEntityValidationException e)
            {
                var outputLines = new List<string>();
                foreach (var eve in e.EntityValidationErrors)
                {
                    outputLines.Add(string.Format(
                        "{0}: Entity of type \"{1}\" in state \"{2}\" has the following validation errors:", DateTime.Now,
                        eve.Entry.Entity.GetType().Name, eve.Entry.State));
                    foreach (var ve in eve.ValidationErrors)
                    {
                        outputLines.Add(string.Format("- Property: \"{0}\", Error: \"{1}\"", ve.PropertyName, ve.ErrorMessage));
                    }
                }

                throw e;
            }
        }

        private bool disposed = false;
        public virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    Debug.WriteLine("UnitOfWork is being disposed");
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}