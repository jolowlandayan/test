﻿using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Configurations
{
    public class MD_Rooms_ComponentsConfiguration : EntityTypeConfiguration<MD_Rooms_Components>
    {
        public MD_Rooms_ComponentsConfiguration()
        {
            ToTable("MD_Rooms_Components");
            HasKey(x => x.RCId);

            Property(x => x.RCId)
                .HasColumnName("RCId")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.RoomId)
                .HasColumnName("RoomId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            HasRequired(x => x.MD_Rooms)
                .WithMany()
                .HasForeignKey(x => x.RoomId)
                .WillCascadeOnDelete(false);

            Property(x => x.RCDescription)
                .HasColumnName("RCDescription")
                .HasColumnType(SqlDbType.VarChar.ToString())
                .HasMaxLength(512);

            Property(x => x.SerialNumber)
               .HasColumnName("SerialNumber")
               .HasColumnType(SqlDbType.VarChar.ToString())
               .HasMaxLength(128);

            Property(x => x.CreatedBy)
               .HasColumnName("CreatedBy")
               .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.CreatedDate)
               .HasColumnName("CreatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString());

            Property(x => x.UpdatedBy)
               .HasColumnName("UpdatedBy")
               .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.UpdatedDate)
               .HasColumnName("UpdatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString());
        }
    }
}
