﻿using MBPS.ProcessingLayer.Core.Dto.In;
using MBPS.ProcessingLayer.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Utilities
{
    public class CoreActivityValidation : ICoreActivityValidation
    {
        private readonly IUnitOfWork _unitOfWork;
        public CoreActivityValidation(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public bool CoreActivityInsertMissingFields(RequestInsertCoreActivityDto coreActivityDetails)
        {
            if (coreActivityDetails.TeamId > 0
                && coreActivityDetails.WorkTypeId > 0
                && coreActivityDetails.IsActive == true
                && coreActivityDetails.CreatedBy >= 0
                && coreActivityDetails.UpdatedBy >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CoreActivityUpdateMissingFields(RequestUpdateCoreActivityDto coreActivityDetails)
        {
            if (coreActivityDetails.CoreActivitiesId >= 0
                && coreActivityDetails.UpdatedBy >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
