﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MBPS.ProcessingLayer.Web.Controllers
{
    public class ManageTeamController : Controller
    {
        // GET: ManageTeam
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ManageTeam()
        {
            return View();
        }
    }
}