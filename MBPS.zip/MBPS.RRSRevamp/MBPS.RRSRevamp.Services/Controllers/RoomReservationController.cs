﻿using AutoMapper;
using MBPS.RRSRevamp.Core.Dto;
using MBPS.RRSRevamp.Core.Interfaces;
using MBPS.RRSRevamp.Core.Models;
using MBPS.RRSRevamp.Services.MBP.RRSRevamp.Core.UOW;
using Ninject;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MBPS.RRSRevamp.Services.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api")]
    public class RoomReservationController : ApiController
    {
        private readonly UnitOfWork _unitOfWork;

        [Inject]
        public RoomReservationController(UnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        #region GET
        [Route("rooms")]
        [HttpGet]
        public List<ResponseRoomDto> GetAllRooms()
        {
            List<ResponseRoomDto> roomDetails = new List<ResponseRoomDto>();
            var rooms = _unitOfWork.RoomsRepository.Get().Where(x => x.IsActive == true);

            foreach (var room in rooms)
            {
                var roomsComponents = _unitOfWork.RoomsComponentRepository.Get().Where(y => y.RoomId == room.RoomId);
                var roomComp = Mapper.Map<IEnumerable<MD_Rooms_Components>, IEnumerable<ResponseRoomsComponentsDto>>(roomsComponents);
                var response = new ResponseRoomDto()
                {
                    RoomId = room.RoomId,
                    BuildingId = room.BuildingId,
                    RoomName = room.RoomName,
                    RoomDescription = room.RoomDescription,
                    FloorNumber = room.FloorNumber,
                    IsActive = room.IsActive,
                    MinCapacity = room.MinCapacity,
                    MaxCapacity = room.MaxCapacity,
                    RoomComponent = roomComp
                };
                roomDetails.Add(response);
            }

            return roomDetails;
        }

        [Route("getRoomReservations/userId/{userid}")]
        [HttpGet]
        public IList<ResponseRoomReservationDto> GetAllRoomsReservation(int userid)
        {
            var roomReservations = _unitOfWork.RoomReservationRepository.GetRoomReservations(userid);

            if (roomReservations.Count() != 0)
            {
                var result = Mapper.Map<IList<TD_RoomReservation>, IList<ResponseRoomReservationDto>>(roomReservations);
                return result;
            }
            return null;
        }

        #endregion

        #region POST
        [Route("rooms/availableRooms/apacity/{capacity}/buildingId/{buildingId}")]
        [HttpPost]
        public IList<ResponseAvailableRoomsDto> GetAllAvailableRooms(HttpRequestMessage request, [FromBody] SearchDatesDto dates, [FromUri] int capacity, [FromUri] int buildingId)
        {
            if (dates != null)
            {
                var result = _unitOfWork.RoomReservationRepository.GetAllAvailableRooms(dates.StartDate, dates.EndDate, capacity, buildingId).ToList();
                if (result == null)
                {
                    return null;
                }
                else
                {
                    var response = Mapper.Map<IList<MD_Rooms>, IList<ResponseAvailableRoomsDto>>(result);
                    return response;
                }
            }
            return null;
        }
        #endregion

        #region PUT
        #endregion
    }
}
