﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Models
{
    public class MD_CoreActivities_Fields_Choices
    {

        public int ChoiceId { get; set; }

        public int FieldId { get; set; }

        public virtual MD_CoreActivities_Fields MD_CoreActivities_Fields { get; set; }

        public int ChoiceNumber { get; set; }

        public string Choice { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int UpdatedBy { get; set; }

        public DateTime UpdatedDate { get; set; }

    }
}
