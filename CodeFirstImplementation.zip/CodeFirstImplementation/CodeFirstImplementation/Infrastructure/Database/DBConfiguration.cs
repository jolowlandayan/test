﻿using CodeFirstImplementation.Infrastructure.Database.Configurations;
using CodeFirstImplementation.Infrastructure.Entities;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CodeFirstImplementation.Infrastructure.Database
{
    public class DBConfiguration : DbContext
    {
        public DBConfiguration() : base("name=local") //db name
        {

        }

        public DbSet<Users> Users { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //insert here all the configuration for each of the entities
            modelBuilder.Configurations.Add(new UsersConfiguration());
            base.OnModelCreating(modelBuilder);
        }
    }
}