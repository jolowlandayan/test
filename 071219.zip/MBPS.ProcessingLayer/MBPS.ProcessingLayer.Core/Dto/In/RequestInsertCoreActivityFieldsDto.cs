﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Dto.In
{
    public class RequestInsertCoreActivityFieldsDto
    {
        public int CoreActivitiesId { get; set; }
        public int FieldTypeId { get; set; }
        public string FieldName { get; set; }
        public int CharLimit { get; set; }
        public bool IsRequired { get; set; }
        public int CreatedBy { get; set; }
    }
}
