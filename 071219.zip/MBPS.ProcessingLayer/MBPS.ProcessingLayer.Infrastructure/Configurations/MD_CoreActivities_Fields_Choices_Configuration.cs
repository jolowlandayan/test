﻿using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Infrastructure.Configurations
{
    public class MD_CoreActivities_Fields_Choices_Configuration : EntityTypeConfiguration<MD_CoreActivities_Fields_Choices>
    {

        public MD_CoreActivities_Fields_Choices_Configuration()
        {
            ToTable("MD_CoreActivities_Fields_Choices");
            HasKey(x => x.ChoiceId);

            Property(x => x.ChoiceId)
                .HasColumnName("ChoiceId")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.FieldId)
                .HasColumnName("FieldId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            HasRequired(x => x.MD_CoreActivities_Fields)
                .WithMany()
                .HasForeignKey(x => x.FieldId)
                .WillCascadeOnDelete(true);

            Property(x => x.ChoiceNumber)
                .HasColumnName("ChoiceNumber")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            Property(x => x.Choice)
                .HasColumnName("Choice")
                .HasColumnType(SqlDbType.VarChar.ToString())
                .HasMaxLength(2048)
                .IsRequired();

            Property(x => x.CreatedBy)
               .HasColumnName("CreatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.CreatedDate)
               .HasColumnName("CreatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();

            Property(x => x.UpdatedBy)
               .HasColumnName("UpdatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.UpdatedDate)
               .HasColumnName("UpdatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();

        }

    }
}
