﻿using MBPS.ProcessingLayer.Core.Models;
using MBPS.ProcessingLayer.Infrastructure.Configurations;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Infrastructure
{
    public class DataContext : DbContext
    {
        public virtual DbSet<Lkp_FieldType> Lkp_FieldType { get; set; }
        public virtual DbSet<MD_CoreActivities> MD_CoreActivities { get; set; }
        public virtual DbSet<MD_CoreActivities_Fields> MD_CoreActivities_Fields { get; set; }
        public virtual DbSet<MD_CoreActivities_Fields_Choices> MD_CoreActivities_Fields_Choices { get; set; }
        
        public DataContext() : base("name=DataContext") { }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new Lkp_FieldType_Configuration());
            modelBuilder.Configurations.Add(new MD_CoreActivities_Configuration());
            modelBuilder.Configurations.Add(new MD_CoreActivities_Fields_Configuration());
            modelBuilder.Configurations.Add(new MD_CoreActivities_Fields_Choices_Configuration());
            base.OnModelCreating(modelBuilder);
        }
    }
}
