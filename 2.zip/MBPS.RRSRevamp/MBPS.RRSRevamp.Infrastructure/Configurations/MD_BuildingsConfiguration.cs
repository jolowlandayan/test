﻿using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Configurations
{
    public class MD_BuildingsConfiguration : EntityTypeConfiguration<MD_Buildings>
    {
        public MD_BuildingsConfiguration()
        {
            ToTable("MD_Buildings");
            HasKey(x => x.BuildingId);

            Property(x => x.BuildingId)
                .HasColumnName("BuildingId")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.BuildingName)
                .HasColumnName("BuildingName")
                .HasColumnType(SqlDbType.VarChar.ToString())
                .HasMaxLength(256)
                .IsRequired();

            Property(x => x.Remarks)
                .HasColumnName("Remarks")
                .HasColumnType(SqlDbType.VarChar.ToString())
                .HasMaxLength(512)
                .IsRequired();

            Property(x => x.IsActive)
                .HasColumnName("IsActive")
                .HasColumnType(SqlDbType.Bit.ToString())
                .IsRequired();

            Property(x => x.CreatedBy)
               .HasColumnName("CreatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.CreatedDate)
               .HasColumnName("CreatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();

            Property(x => x.UpdatedBy)
               .HasColumnName("UpdatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.UpdatedDate)
               .HasColumnName("UpdatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();
        }
    }
}
