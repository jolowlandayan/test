﻿using CodeFirstImplementation.Infrastructure.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CodeFirstImplementation.Infrastructure.Interfaces
{
    public interface IUserRepository : IRepository<Users>
    {
    }
}