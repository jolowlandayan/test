﻿using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Core.Dto
{
    public class ResponseRoomReservationDto
    {
        public int UserId { get; set; }

        public int RoomId { get; set; }

        public virtual MD_Rooms MD_Rooms { get; set; }

        public DateTime StartDateTime { get; set; }

        public DateTime EndDateTime { get; set; }

        public int ReservationStatusId { get; set; }

        public virtual Lkp_ReservationStatus Lkp_ReservationStatus { get; set; }
    }
}
