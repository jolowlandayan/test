﻿using MBPS.RRSRevamp.Core.Interfaces;
using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Repositories
{
    public class Lkp_ReservationStatusRepository : GenericRepository<Lkp_ReservationStatus>, ILkp_ReservationStatusRepository
    {
        public Lkp_ReservationStatusRepository() { }
        public Lkp_ReservationStatusRepository(DataContext Context) : base(Context) { }
    }
}
