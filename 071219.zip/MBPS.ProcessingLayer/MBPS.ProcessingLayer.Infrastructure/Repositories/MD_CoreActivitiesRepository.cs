﻿using MBPS.ProcessingLayer.Core.Dto.In;
using MBPS.ProcessingLayer.Core.Dto.Out;
using MBPS.ProcessingLayer.Core.Interfaces;
using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Infrastructure.Repositories
{
    public class MD_CoreActivitiesRepository : GenericRepository<MD_CoreActivities>, IMD_CoreActivitiesRepository
    {
        public MD_CoreActivitiesRepository() { }
        public MD_CoreActivitiesRepository(DataContext Context) : base(Context) { }

        public IList<ResponseTeamsDto> GetAllTeams()
        {
            try
            {
                var teamNames = Context.Database.SqlQuery<ResponseTeamsDto>(@"SELECT [TeamId], [TeamName] FROM [MBPS_ProcessingLayer].[dbo].[LVW_WorkTypesPerTeam]").ToList();
                var response = teamNames.GroupBy(x => new { x.TeamId, x.TeamName })
                    .Select(x => x.First())
                    .ToList();
                return response;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public IList<ResponseWorktypesDto> GetAllWorktypesByTeam(int teamid)
        {
            try
            {
                var coreActivitiesFromView = Context.Database.SqlQuery<ResponseWorktypesDto>(@"SELECT B.[CoreActivitiesId]
                                                                                              ,A.[TeamId]
                                                                                              ,A.[WorkTypeId]
                                                                                              ,A.[WorkType]
                                                                                              ,B.[IsActive]
                                                                                                FROM  [MBPS_ProcessingLayer].[dbo].[LVW_WorkTypesPerTeam] A
                                                                                                LEFT JOIN [MBPS_ProcessingLayer].[dbo].[MD_CoreActivities] B
                                                                                                ON A.WorkTypeId = B.WorkTypeId
                                                                                                WHERE A.[TeamId] = @TeamId"
                                                                                        , new SqlParameter("TeamId", teamid))
                                                                                        .ToList();
                return coreActivitiesFromView;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public MD_CoreActivities GetCoreActivityById(int worktypeid)
        {
            var result = Context.MD_CoreActivities.Where(x => x.WorkTypeId == worktypeid).FirstOrDefault();
            return result;
        }
    }
}
