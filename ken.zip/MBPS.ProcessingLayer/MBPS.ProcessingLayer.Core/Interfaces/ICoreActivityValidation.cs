﻿using MBPS.ProcessingLayer.Core.Dto.In;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Interfaces
{
    public interface ICoreActivityValidation
    {
        bool CoreActivityInsertMissingFields(RequestInsertCoreActivityDto coreActivityDetails);
        bool CoreActivityUpdateMissingFields(RequestUpdateCoreActivityDto coreActivityDetails);
    }
}
