﻿using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Infrastructure.Configurations
{
    public class MD_CoreActivities_Fields_Configuration : EntityTypeConfiguration<MD_CoreActivities_Fields>
    {
        public MD_CoreActivities_Fields_Configuration()
        {

            ToTable("MD_CoreActivities_Fields");
            HasKey(x => x.FieldId);

            Property(x => x.FieldId)
                .HasColumnName("FieldId")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.CoreActivitiesId)
                .HasColumnName("CoreActivitiesId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            HasRequired(x => x.MD_CoreActivities)
                .WithMany()
                .HasForeignKey(x => x.CoreActivitiesId)
                .WillCascadeOnDelete(true);

            Property(x => x.FieldTypeId)
                .HasColumnName("FieldTypeId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            HasRequired(x => x.Lkp_FieldType)
                .WithMany()
                .HasForeignKey(x => x.FieldTypeId)
                .WillCascadeOnDelete(true);

            Property(x => x.FieldName)
                .HasColumnName("FieldName")
                .HasColumnType(SqlDbType.VarChar.ToString())
                .HasMaxLength(512)
                .IsRequired();

            Property(x => x.CharLimit)
                .HasColumnName("CharLimit")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            Property(x => x.IsRequired)
                .HasColumnName("IsRequired")
                .HasColumnType(SqlDbType.Bit.ToString())
                .IsRequired();

            Property(x => x.CreatedBy)
               .HasColumnName("CreatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.CreatedDate)
               .HasColumnName("CreatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();

            Property(x => x.UpdatedBy)
               .HasColumnName("UpdatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.UpdatedDate)
               .HasColumnName("UpdatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();

        }

    }
}
