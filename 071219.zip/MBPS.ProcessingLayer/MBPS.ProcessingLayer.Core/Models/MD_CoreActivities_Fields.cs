﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Models
{
    public class MD_CoreActivities_Fields
    {

        public int FieldId { get; set; }

        public int CoreActivitiesId { get; set; }

        public virtual MD_CoreActivities MD_CoreActivities { get; set; }

        public int FieldTypeId { get; set; }

        public virtual Lkp_FieldType Lkp_FieldType { get; set; }

        public string FieldName { get; set; }

        public int CharLimit { get; set; }

        public bool IsRequired { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int UpdatedBy { get; set; }

        public DateTime UpdatedDate { get; set; }


    }
}
