﻿using AutoMapper;
using CodeFirstImplementation.Infrastructure.DTOs;
using CodeFirstImplementation.Infrastructure.Entities;
using CodeFirstImplementation.Infrastructure.UOW;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CodeFirstImplementation.Controllers
{
    [RoutePrefix("api")]
    public class UsersController : ApiController
    {
        private readonly UnitOfWork _user;

        [Inject]
        public UsersController(UnitOfWork User)
        {
            _user = User;
        }

        #region GET
        [Route("users")]
        [HttpGet]
        public IEnumerable<UserDTO> GetUsers()
        {
            var userList = new List<UserDTO>();
            var user = _user.UsersRepository.Get();

            Mapper.Map<IEnumerable<Users>, IEnumerable<UserDTO>>(user, userList);
            return userList;
        }
        #endregion

        #region POST
        [Route("user/insert")]
        [HttpPost]
        public HttpResponseMessage Post(HttpRequestMessage request, [FromBody] Users user)
        {
            HttpStatusCode httpStatus;
            try
            {
                var userInsert = new Users()
                {
                    FirstName = user.FirstName,
                    LastName = user.LastName,
                    MiddleName = user.MiddleName,
                };

                Mapper.Map<Users, UserDTO>(userInsert);
                _user.UsersRepository.Insert(userInsert);
                _user.Save();
                httpStatus = HttpStatusCode.OK;
                return request.CreateResponse(httpStatus, "Success");
            }
            catch (SystemException e)
            {
                httpStatus = HttpStatusCode.InternalServerError;
                return request.CreateResponse(httpStatus, e.Message);
            }

        }
        #endregion

        #region POST
        [Route("user/update/{id}")]
        [HttpPut]
        public HttpResponseMessage Update(HttpRequestMessage request, [FromUri] int id, [FromBody] UserDTO users)
        {
            HttpStatusCode httpStatus;

            var userExisting = _user.UsersRepository.GetByID(id);

            var user = Mapper.Map<UserDTO, Users>(users);

            try
            {
                if (userExisting != null)
                {
                    userExisting.FirstName = user.FirstName;
                    userExisting.LastName = user.LastName;
                    userExisting.MiddleName = user.MiddleName;

                    _user.UsersRepository.Update(userExisting);
                    _user.Save();
                }

                httpStatus = HttpStatusCode.OK;
                return request.CreateResponse(httpStatus, userExisting);
            }
            catch (SystemException e)
            {
                httpStatus = HttpStatusCode.InternalServerError;
                return request.CreateResponse(httpStatus);
            }

        }
        #endregion
    }
}
