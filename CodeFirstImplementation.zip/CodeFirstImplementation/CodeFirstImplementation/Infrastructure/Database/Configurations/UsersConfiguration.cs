﻿using CodeFirstImplementation.Infrastructure.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace CodeFirstImplementation.Infrastructure.Database.Configurations
{
    public class UsersConfiguration : EntityTypeConfiguration<Users>
    {
        public UsersConfiguration()
        {
            ToTable("Users");
            HasKey(x => x.Id);

            Property(x => x.Id)
                .HasColumnName("Id")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.FirstName)
                .HasColumnName("FirstName")
                .HasColumnType(SqlDbType.NVarChar.ToString());

            Property(x => x.LastName)
                .HasColumnName("LastName")
                .HasColumnType(SqlDbType.NVarChar.ToString());

            Property(x => x.MiddleName)
               .HasColumnName("MiddleName")
               .HasColumnType(SqlDbType.NVarChar.ToString());
        }
    }
}