﻿using AutoMapper;
using MBPS.ProcessingLayer.Core.Dto.In;
using MBPS.ProcessingLayer.Core.Dto.Out;
using MBPS.ProcessingLayer.Core.Interfaces;
using MBPS.ProcessingLayer.Core.Models;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MBPS.ProcessingLayer.Services.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/coreactivities")]
    public class CoreActivitiesController : ApiController
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IProcessingLayerValidations _coreActivityValidation;

        [Inject]
        public CoreActivitiesController(IUnitOfWork unitOfWork, IProcessingLayerValidations coreActivityValidation)
        {
            _unitOfWork = unitOfWork;
            _coreActivityValidation = coreActivityValidation;
        }

        #region GET
        [HttpGet]
        [Route("getAllTeams")]
        public IList<ResponseTeamsDto> GetAllTeams()
        {
            var result = _unitOfWork.CoreActivitiesRepository().GetAllTeams();
            return result;
        }

        [HttpGet]
        [Route("getAllWorkTypesByTeam/teamId/{teamid}")]
        public IList<ResponseWorktypesDto> GetAllWorkTypes([FromUri] int teamid)
        {
            if (teamid >= 0)
            {
                var result = _unitOfWork.CoreActivitiesRepository().GetAllWorktypesByTeam(teamid);
                return result;
            }
            return null;
        }
        #endregion

        #region POST
        [HttpPost]
        [Route("insertCoreActivity")]
        public HttpResponseMessage Post(HttpRequestMessage request, [FromBody] RequestInsertCoreActivityDto coreactivitydetails)
        {
            if (coreactivitydetails != null)
            {
                var isCoreActivityDetailsValid = _coreActivityValidation.CoreActivityInsertMissingFields(coreactivitydetails);
                if (isCoreActivityDetailsValid)
                {
                    var coreActivity = Mapper.Map<RequestInsertCoreActivityDto, MD_CoreActivities>(coreactivitydetails);
                    coreActivity.CreatedDate = DateTime.Now;
                    coreActivity.UpdatedDate = DateTime.Now;
                    try
                    {
                        _unitOfWork.CoreActivitiesRepository().Insert(coreActivity);
                        _unitOfWork.Save();
                        return request.CreateResponse(HttpStatusCode.OK, "Core activity was saved successfully.");
                    }
                    catch (Exception e)
                    {
                        return request.CreateResponse(HttpStatusCode.InternalServerError, e.Message);
                    }
                }
                else
                {
                    return request.CreateResponse(HttpStatusCode.InternalServerError, "There are missing fields in the core activity details.");
                }
            }
            else
            {
                return request.CreateResponse(HttpStatusCode.InternalServerError, "Core Activity Details cannot be null.");
            }
        }
        #endregion

        #region PUT
        [HttpPut]
        [Route("updateCoreActivity")]
        public HttpResponseMessage UpdateCoreActivity(HttpRequestMessage request, [FromBody] RequestUpdateCoreActivityDto coreactivitydetails)
        {
            if (coreactivitydetails != null)
            {
                var isCoreActivityDetailsValid = _coreActivityValidation.CoreActivityUpdateMissingFields(coreactivitydetails);
                if (isCoreActivityDetailsValid)
                {
                    var coreActivity = Mapper.Map<RequestUpdateCoreActivityDto, MD_CoreActivities>(coreactivitydetails);
                    var result = _unitOfWork.CoreActivitiesRepository().GetCoreActivityById(coreActivity.WorkTypeId);

                    result.UpdatedDate = DateTime.Now;
                    result.IsActive = coreactivitydetails.IsActive;
                    try
                    {
                        _unitOfWork.CoreActivitiesRepository().Update(result);
                        _unitOfWork.Save();
                        return request.CreateResponse(HttpStatusCode.OK, "Core activity was updated successfully.");
                    }
                    catch (Exception e)
                    {
                        return request.CreateResponse(HttpStatusCode.InternalServerError, e.Message);
                    }
                }
                else
                {
                    return request.CreateResponse(HttpStatusCode.InternalServerError, "There are missing fields in the core activity details.");
                }
            }
            else
            {
                return request.CreateResponse(HttpStatusCode.InternalServerError, "Core Activity Details cannot be null.");
            }
        }
        #endregion
    }
}
