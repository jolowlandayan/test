﻿using MBPS.ProcessingLayer.Core.Interfaces;
using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Infrastructure.Repositories
{
    public class Lkp_FieldTypeRepository : GenericRepository<Lkp_FieldType>, ILkp_FieldTypeRepository
    {
        public Lkp_FieldTypeRepository() { }
        public Lkp_FieldTypeRepository(DataContext Context) : base(Context) { }

        public IList<Lkp_FieldType> GetAllFieldType()
        {
            return Context.Lkp_FieldType.ToList();
        }

    }
}
