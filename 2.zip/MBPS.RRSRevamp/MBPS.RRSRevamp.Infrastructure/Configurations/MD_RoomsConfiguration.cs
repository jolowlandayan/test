﻿using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Configurations
{
    public class MD_RoomsConfiguration : EntityTypeConfiguration<MD_Rooms>
    {
        public MD_RoomsConfiguration()
        {
            ToTable("MD_Rooms");
            HasKey(x => x.RoomId);

            Property(x => x.RoomId)
                .HasColumnName("RoomId")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.BuildingId)
                .HasColumnName("BuildingId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            HasRequired(x => x.MD_Buildings)
                .WithMany()
                .HasForeignKey(x => x.BuildingId)
                .WillCascadeOnDelete(false);

            Property(x => x.RoomName)
                .HasColumnName("RoomName")
                .HasColumnType(SqlDbType.VarChar.ToString())
                .HasMaxLength(128);

            Property(x => x.RoomDescription)
              .HasColumnName("RoomDescription")
              .HasColumnType(SqlDbType.VarChar.ToString())
              .HasMaxLength(512);

            Property(x => x.FloorNumber)
              .HasColumnName("FloorNumber")
              .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.MinCapacity)
             .HasColumnName("MinCapacity")
             .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.MaxCapacity)
             .HasColumnName("MaxCapacity")
             .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.IsActive)
             .HasColumnName("IsActive")
             .HasColumnType(SqlDbType.Bit.ToString());

            Property(x => x.CreatedBy)
               .HasColumnName("CreatedBy")
               .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.CreatedDate)
               .HasColumnName("CreatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString());

            Property(x => x.UpdatedBy)
               .HasColumnName("UpdatedBy")
               .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.UpdatedDate)
               .HasColumnName("UpdatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString());
            
        }
    }
}
