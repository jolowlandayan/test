namespace MBPS.ProcessingLayer.Services.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CoreActivitiesTable : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Lkp_FieldType",
                c => new
                    {
                        FieldTypeId = c.Int(nullable: false, identity: true),
                        FieldType = c.String(nullable: false, maxLength: 128, unicode: false),
                        FieldTypeDescription = c.String(nullable: false, maxLength: 512, unicode: false),
                        CreatedBy = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false, storeType: "smalldatetime"),
                        UpdatedBy = c.Int(nullable: false),
                        UpdatedDate = c.DateTime(nullable: false, storeType: "smalldatetime"),
                    })
                .PrimaryKey(t => t.FieldTypeId);
            
            CreateTable(
                "dbo.MD_CoreActivities",
                c => new
                    {
                        CoreActivitiesId = c.Int(nullable: false, identity: true),
                        TeamId = c.Int(nullable: false),
                        WorkTypeId = c.Int(nullable: false),
                        IsActive = c.Boolean(nullable: false),
                        CreatedBy = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false, storeType: "smalldatetime"),
                        UpdatedBy = c.Int(nullable: false),
                        UpdatedDate = c.DateTime(nullable: false, storeType: "smalldatetime"),
                    })
                .PrimaryKey(t => t.CoreActivitiesId);
            
            CreateTable(
                "dbo.MD_CoreActivities_Fields",
                c => new
                    {
                        FieldId = c.Int(nullable: false, identity: true),
                        CoreActivitiesId = c.Int(nullable: false),
                        FieldTypeId = c.Int(nullable: false),
                        FieldName = c.String(nullable: false, maxLength: 512, unicode: false),
                        CharLimit = c.Int(nullable: false),
                        IsRequired = c.Boolean(nullable: false),
                        CreatedBy = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false, storeType: "smalldatetime"),
                        UpdatedBy = c.Int(nullable: false),
                        UpdatedDate = c.DateTime(nullable: false, storeType: "smalldatetime"),
                    })
                .PrimaryKey(t => t.FieldId)
                .ForeignKey("dbo.Lkp_FieldType", t => t.FieldTypeId, cascadeDelete: true)
                .ForeignKey("dbo.MD_CoreActivities", t => t.CoreActivitiesId, cascadeDelete: true)
                .Index(t => t.CoreActivitiesId)
                .Index(t => t.FieldTypeId);
            
            CreateTable(
                "dbo.MD_CoreActivities_Fields_Choices",
                c => new
                    {
                        ChoiceId = c.Int(nullable: false, identity: true),
                        FieldId = c.Int(nullable: false),
                        ChoiceNumber = c.Int(nullable: false),
                        Choice = c.String(nullable: false, maxLength: 2048, unicode: false),
                        CreatedBy = c.Int(nullable: false),
                        CreatedDate = c.DateTime(nullable: false, storeType: "smalldatetime"),
                        UpdatedBy = c.Int(nullable: false),
                        UpdatedDate = c.DateTime(nullable: false, storeType: "smalldatetime"),
                    })
                .PrimaryKey(t => t.ChoiceId)
                .ForeignKey("dbo.MD_CoreActivities_Fields", t => t.FieldId, cascadeDelete: true)
                .Index(t => t.FieldId);

            Sql("ALTER TABLE Lkp_FieldType ADD CONSTRAINT [DF_Lkp_FieldType_CreatedDate] DEFAULT GETDATE() FOR CreatedDate");
            Sql("ALTER TABLE Lkp_FieldType ADD CONSTRAINT [DF_Lkp_FieldType_UpdatedDate] DEFAULT GETDATE() FOR UpdatedDate");

            AlterColumn("dbo.MD_CoreActivities", "IsActive", c => c.Boolean(nullable: false, defaultValue: true));
            Sql("ALTER TABLE MD_CoreActivities ADD CONSTRAINT [DF_MD_CoreActivities_CreatedDate] DEFAULT GETDATE() FOR CreatedDate");
            Sql("ALTER TABLE MD_CoreActivities ADD CONSTRAINT [DF_MD_CoreActivities_UpdatedDate] DEFAULT GETDATE() FOR UpdatedDate");

            AlterColumn("dbo.MD_CoreActivities_Fields", "IsRequired", c => c.Boolean(nullable: false, defaultValue: true));
            Sql("ALTER TABLE MD_CoreActivities_Fields ADD CONSTRAINT [DF_MD_CoreActivities_Fields_CreatedDate] DEFAULT GETDATE() FOR CreatedDate");
            Sql("ALTER TABLE MD_CoreActivities_Fields ADD CONSTRAINT [DF_MD_CoreActivities_Fields_UpdatedDate] DEFAULT GETDATE() FOR UpdatedDate");

            Sql("ALTER TABLE MD_CoreActivities_Fields_Choices ADD CONSTRAINT [DF_MD_CoreActivities_Fields_Choices_CreatedDate] DEFAULT GETDATE() FOR CreatedDate");
            Sql("ALTER TABLE MD_CoreActivities_Fields_Choices ADD CONSTRAINT [DF_MD_CoreActivities_Fields_Choices_UpdatedDate] DEFAULT GETDATE() FOR UpdatedDate");

        }
        
        public override void Down()
        {
            DropForeignKey("dbo.MD_CoreActivities_Fields_Choices", "FieldId", "dbo.MD_CoreActivities_Fields");
            DropForeignKey("dbo.MD_CoreActivities_Fields", "CoreActivitiesId", "dbo.MD_CoreActivities");
            DropForeignKey("dbo.MD_CoreActivities_Fields", "FieldTypeId", "dbo.Lkp_FieldType");
            DropIndex("dbo.MD_CoreActivities_Fields_Choices", new[] { "FieldId" });
            DropIndex("dbo.MD_CoreActivities_Fields", new[] { "FieldTypeId" });
            DropIndex("dbo.MD_CoreActivities_Fields", new[] { "CoreActivitiesId" });
            DropTable("dbo.MD_CoreActivities_Fields_Choices");
            DropTable("dbo.MD_CoreActivities_Fields");
            DropTable("dbo.MD_CoreActivities");
            DropTable("dbo.Lkp_FieldType");
        }
    }
}
