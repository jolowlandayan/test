﻿using AutoMapper;
using MBPS.RRSRevamp.Core.Dto;
using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace MBPS.RRSRevamp.Services
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            CreateMap();
        }

        private void CreateMap()
        {
            Mapper.CreateMap<MD_Rooms, ResponseRoomDto>()
                .ForMember(obj => obj.RoomId, dto => dto.MapFrom(x => x.RoomId))
                .ForMember(obj => obj.BuildingId, dto => dto.MapFrom(x => x.BuildingId))
                .ForMember(obj => obj.RoomName, dto => dto.MapFrom(x => x.RoomName))
                .ForMember(obj => obj.RoomDescription, dto => dto.MapFrom(x => x.RoomDescription))
                .ForMember(obj => obj.FloorNumber, dto => dto.MapFrom(x => x.FloorNumber))
                .ForMember(obj => obj.IsActive, dto => dto.MapFrom(x => x.IsActive))
                .ForMember(obj => obj.MinCapacity, dto => dto.MapFrom(x => x.MinCapacity))
                .ForMember(obj => obj.MaxCapacity, dto => dto.MapFrom(x => x.MaxCapacity));

            Mapper.CreateMap<MD_Rooms, ResponseAvailableRoomsDto>()
                .ForMember(obj => obj.RoomId, dto => dto.MapFrom(x => x.RoomId))
                .ForMember(obj => obj.RoomName, dto => dto.MapFrom(x => x.RoomName))
                .ForMember(obj => obj.RoomDescription, dto => dto.MapFrom(x => x.RoomDescription))
                .ForMember(obj => obj.FloorNumber, dto => dto.MapFrom(x => x.FloorNumber))
                .ForMember(obj => obj.MinCapacity, dto => dto.MapFrom(x => x.MinCapacity))
                .ForMember(obj => obj.MaxCapacity, dto => dto.MapFrom(x => x.MaxCapacity));

            Mapper.CreateMap<MD_Rooms_Components, ResponseRoomsComponentsDto>()
                .ForMember(obj => obj.RoomId, dto => dto.MapFrom(x => x.RoomId))
                .ForMember(obj => obj.RCDescription, dto => dto.MapFrom(x => x.RCDescription))
                .ForMember(obj => obj.SerialNumber, dto => dto.MapFrom(x => x.SerialNumber));

            Mapper.CreateMap<TD_RoomReservation, ResponseRoomReservationDto>()
                .ForMember(obj => obj.UserId, dto => dto.MapFrom(x => x.UserId))
                .ForMember(obj => obj.RoomId, dto => dto.MapFrom(x => x.RoomId))
                .ForMember(obj => obj.MD_Rooms, dto => dto.MapFrom(x => x.MD_Rooms))
                .ForMember(obj => obj.StartDateTime, dto => dto.MapFrom(x => x.StartDateTime))
                .ForMember(obj => obj.EndDateTime, dto => dto.MapFrom(x => x.EndDateTime))
                .ForMember(obj => obj.ReservationStatusId, dto => dto.MapFrom(x => x.ReservationStatusId))
                .ForMember(obj => obj.Lkp_ReservationStatus, dto => dto.MapFrom(x => x.Lkp_ReservationStatus));


        }
    }
}
