﻿using MBPS.RRSRevamp.Core.Interfaces;
using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Repositories
{
    public class MD_RoomsComponentsRepository : GenericRepository<MD_Rooms_Components>, IMD_RoomsComponentsRepository
    {
        public MD_RoomsComponentsRepository() { }
        public MD_RoomsComponentsRepository(DataContext Context) : base(Context) { }
        public MD_Rooms_Components GetByRoomId(int roomid)
        {
            return Context.MD_Rooms_Components.FirstOrDefault(x => x.RoomId == roomid);
        }
    }
}
