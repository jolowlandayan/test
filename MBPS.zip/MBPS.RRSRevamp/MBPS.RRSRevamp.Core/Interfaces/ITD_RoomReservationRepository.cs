﻿using MBPS.RRSRevamp.Core.Dto;
using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Core.Interfaces
{
    public interface ITD_RoomReservationRepository
    {
        IEnumerable<MD_Rooms> GetAllAvailableRooms(DateTime startDate, DateTime endDate, int capacity, int buildingId);
    }
}
