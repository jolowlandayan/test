﻿namespace CodeFirstImplementation.Infrastructure.Repositories
{
    public class Customer
    {
    }
}