﻿using MBPS.ProcessingLayer.Core.Dto.In;
using MBPS.ProcessingLayer.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Utilities
{
    public class ProcessingLayerValidations : IProcessingLayerValidations
    {
        private readonly IUnitOfWork _unitOfWork;
        public ProcessingLayerValidations(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }
        public bool CoreActivityInsertMissingFields(RequestInsertCoreActivityDto coreActivityDetails)
        {
            if (coreActivityDetails.TeamId > 0
                && coreActivityDetails.WorkTypeId > 0
                && coreActivityDetails.IsActive == true
                && coreActivityDetails.CreatedBy >= 0
                && coreActivityDetails.UpdatedBy >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool CoreActivityUpdateMissingFields(RequestUpdateCoreActivityDto coreActivityDetails)
        {
            if (coreActivityDetails.WorkTypeId >= 0
                && coreActivityDetails.UpdatedBy >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool InsertCoreActivityFieldValidation(RequestInsertCoreActivityFieldsDto coreActivityFieldDetails)
        {
            if (coreActivityFieldDetails.CoreActivitiesId > 0
               && coreActivityFieldDetails.FieldTypeId > 0
               && !string.IsNullOrEmpty(coreActivityFieldDetails.FieldName)
               && coreActivityFieldDetails.CharLimit < 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
