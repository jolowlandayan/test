﻿using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Infrastructure.Configurations
{
    public class MD_CoreActivities_Configuration : EntityTypeConfiguration<MD_CoreActivities>
    {
        public MD_CoreActivities_Configuration()
        {
            ToTable("MD_CoreActivities");
            HasKey(x => x.CoreActivitiesId);

            Property(x => x.CoreActivitiesId)
                .HasColumnName("CoreActivitiesId")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.TeamId)
                .HasColumnName("TeamId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            Property(x => x.WorkTypeId)
                .HasColumnName("WorkTypeId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            Property(x => x.IsActive)
                .HasColumnName("IsActive")
                .HasColumnType(SqlDbType.Bit.ToString())
                .IsRequired();

            Property(x => x.CreatedBy)
               .HasColumnName("CreatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.CreatedDate)
               .HasColumnName("CreatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();

            Property(x => x.UpdatedBy)
               .HasColumnName("UpdatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.UpdatedDate)
               .HasColumnName("UpdatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();

        }

    }
}
