﻿using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Core.Interfaces
{
    public interface IMD_BuildingsRepository : IRepository<MD_Buildings>
    {
        MD_Buildings GetBuildingsById(int id);
    }
}
