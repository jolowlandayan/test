﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Dto.In
{
    public class RequestInsertCoreActivityDto
    {
        public int TeamId { get; set; }
        public int WorkTypeId { get; set; }
        public bool IsActive { get; set; }
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
    }
}
