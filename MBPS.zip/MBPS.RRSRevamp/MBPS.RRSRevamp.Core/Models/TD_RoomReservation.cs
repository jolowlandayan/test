﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Core.Models
{
    public class TD_RoomReservation
    {
        public int ReservationId { get; set; }

        public int UserId { get; set; }

        public int RoomId { get; set; }

        public virtual MD_Rooms MD_Rooms { get; set; }

        public DateTime StartDateTime { get; set; }

        public DateTime EndDateTime { get; set; }

        public string Remarks { get; set; }

        public int ReservationStatusId { get; set; }

        public virtual Lkp_ReservationStatus Lkp_ReservationStatus { get; set; }

        public int ApprovedBy { get; set; }

        public DateTime ApprovedDate { get; set; }

        public int CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int UpdatedBy { get; set; }

        public DateTime UpdatedDate { get; set; }
    }
}
