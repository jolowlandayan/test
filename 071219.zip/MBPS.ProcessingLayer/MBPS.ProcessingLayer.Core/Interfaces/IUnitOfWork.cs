﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Interfaces
{
    public interface IUnitOfWork
    {
        ILkp_FieldTypeRepository FieldTypeRepository();
        IMD_CoreActivities_FieldsRepository CoreActitiviesFieldsRepository();
        IMD_CoreActivities_Fields_ChoicesRepository CoreActivitiesFieldsChoicesRepository();
        IMD_CoreActivitiesRepository CoreActivitiesRepository();
        void Save();
        void Dispose();

    }
}
