﻿using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Interfaces
{
    public interface IMD_CoreActivities_Fields_ChoicesRepository : IRepository<MD_CoreActivities_Fields_Choices>
    {
        
    }
}
