﻿using AutoMapper;
using MBPS.ProcessingLayer.Core.Dto.In;
using MBPS.ProcessingLayer.Core.Dto.Out;
using MBPS.ProcessingLayer.Core.Interfaces;
using MBPS.ProcessingLayer.Core.Models;
using Ninject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;

namespace MBPS.ProcessingLayer.Services.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/forms")]
    public class FormsController : ApiController
    {
        private IUnitOfWork _unitOfWork;

        [Inject]
        public FormsController(IUnitOfWork UnitOfWork)
        {
            _unitOfWork = UnitOfWork;
        }

        #region GET
        [HttpGet]
        [Route("getAllCoreActivityFields")]
        public HttpResponseMessage GetAllCoreActivityFields(HttpRequestMessage request)
        {
            try
            {
                var coreActivityFields = _unitOfWork.CoreActitiviesFieldsRepository().GetAllCoreActivityFields();
                var response = Mapper.Map<IList<MD_CoreActivities_Fields>, IList<ResponseCoreActivityFieldsDto>>(coreActivityFields);
                return request.CreateResponse(HttpStatusCode.OK, response);
            }
            catch (Exception e)
            {
                return request.CreateResponse(HttpStatusCode.InternalServerError, e.Message);
            }
            
        }

        [HttpGet]
        [Route("getCoreActivityFields/coreActivityId/{coreactivityid}")]
        public HttpResponseMessage GetCoreActivityFields(HttpRequestMessage request, [FromUri]int coreactivityid)
        {
            if (coreactivityid >= 0)
            {
                try
                {
                    var response = _unitOfWork.CoreActitiviesFieldsRepository().GetCoreActivityFieldsById(coreactivityid);
                    return request.CreateResponse(HttpStatusCode.OK, response);
                }
                catch (Exception e)
                {
                    return request.CreateResponse(HttpStatusCode.InternalServerError, e.Message);
                }
            }
            else
            {
                return request.CreateResponse(HttpStatusCode.InternalServerError, "Core activity id cannot be null.");
            }
        }
        #endregion

        #region POST
        [HttpPost]
        [Route("insertCoreActivityFields")]
        public HttpResponseMessage Post(HttpRequestMessage request, [FromBody]IList<RequestInsertCoreActivityFieldsDto> coreactivityfields)
        {

            return null;
        }
        #endregion

        #region PUT

        #endregion
    }
}
           