﻿using MBPS.ProcessingLayer.Core.Dto.Out;
using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Core.Interfaces
{
    public interface IMD_CoreActivitiesRepository : IRepository<MD_CoreActivities>
    {
        IList<ResponseTeamsDto> GetAllTeams();
        IList<ResponseWorktypesDto> GetAllWorktypesByTeam(int teamid);
        MD_CoreActivities GetCoreActivityById(int coreactivitiesid)
    }
}
