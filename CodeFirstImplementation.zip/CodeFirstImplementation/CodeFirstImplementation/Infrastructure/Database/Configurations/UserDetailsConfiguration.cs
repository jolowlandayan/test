﻿using CodeFirstImplementation.Infrastructure.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;

namespace CodeFirstImplementation.Infrastructure.Database.Configurations
{
    public class UserDetailsConfiguration : EntityTypeConfiguration<UserDetails>
    {
        public UserDetailsConfiguration()
        {
            ToTable("UserDetails");
            HasKey(x => x.Id);

            Property(x => x.Id)
                .HasColumnName("Id")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.Birthday)
                .HasColumnName("Birthday")
                .HasColumnType(SqlDbType.NVarChar.ToString());

            Property(x => x.Address)
                .HasColumnName("Address")
                .HasColumnType(SqlDbType.NVarChar.ToString());

            Property(x => x.Email)
                .HasColumnName("Email")
                .HasColumnType(SqlDbType.NVarChar.ToString());

            Property(x => x.UserId)
                .HasColumnName("UserId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            HasRequired(x => x.Users)
                .WithMany()
                .HasForeignKey(x => x.UserId)
                .WillCascadeOnDelete(false);
        }
    }
}