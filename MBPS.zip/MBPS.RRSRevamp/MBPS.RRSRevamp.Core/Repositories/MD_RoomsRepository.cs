﻿using MBPS.RRSRevamp.Core.Dto;
using MBPS.RRSRevamp.Core.Interfaces;
using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Repositories
{
    public class MD_RoomsRepository : GenericRepository<MD_Rooms>, IMD_RoomsRepository
    {
        public MD_RoomsRepository() { }
        public MD_RoomsRepository(DataContext Context) : base(Context) { }
        public MD_Rooms GetRoomById(int id)
        {
            return Context.MD_Rooms.FirstOrDefault(x => x.RoomId == id);
        }

        public IQueryable<MD_Rooms> SearchByRoomName(string roomName)
        {
            return Context.MD_Rooms.Where(x => x.RoomName.ToLower().Contains(roomName.ToLower()));
        }

        public IEnumerable<MD_Rooms> SearchByFloor(int floor)
        {
            return Context.MD_Rooms.Where(x => x.FloorNumber == floor);
        }

        public IEnumerable<MD_Rooms> SearchByMinCapacity(int capacity)
        {
            return Context.MD_Rooms.Where(x => x.MinCapacity == capacity);
        }

        public IEnumerable<MD_Rooms> GetAllRooms()
        {
            return Context.MD_Rooms.ToList();
        }
    }
}
