﻿using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Configurations
{
    public class TD_RoomReservationConfiguration : EntityTypeConfiguration<TD_RoomReservation>
    {
        public TD_RoomReservationConfiguration()
        {
            ToTable("TD_RoomReservation");
            HasKey(x => x.ReservationId);

            Property(x => x.ReservationId)
                .HasColumnName("ReservationId")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.UserId)
                .HasColumnName("UserId")
                .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.RoomId)
                .HasColumnName("RoomId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            HasRequired(x => x.MD_Rooms)
                .WithMany()
                .HasForeignKey(x => x.RoomId)
                .WillCascadeOnDelete(false);

            Property(x => x.StartDateTime)
               .HasColumnName("StartDateTime")
               .HasColumnType(SqlDbType.DateTime.ToString());

            Property(x => x.EndDateTime)
               .HasColumnName("EndDateTime")
               .HasColumnType(SqlDbType.DateTime.ToString());

            Property(x => x.Remarks)
                .HasColumnName("Remarks")
                .HasColumnType(SqlDbType.VarChar.ToString())
                .HasMaxLength(512);

            Property(x => x.ReservationStatusId)
                .HasColumnName("ReservationStatusId")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsRequired();

            HasRequired(x => x.Lkp_ReservationStatus)
                .WithMany()
                .HasForeignKey(x => x.ReservationStatusId)
                .WillCascadeOnDelete(false);

            Property(x => x.ApprovedBy)
                .HasColumnName("ApprovedBy")
                .HasColumnType(SqlDbType.Int.ToString())
                .IsOptional();

            Property(x => x.ApprovedDate)
               .HasColumnName("ApprovedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsOptional();


            Property(x => x.CreatedBy)
               .HasColumnName("CreatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.CreatedDate)
               .HasColumnName("CreatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();

            Property(x => x.UpdatedBy)
               .HasColumnName("UpdatedBy")
               .HasColumnType(SqlDbType.Int.ToString())
               .IsRequired();

            Property(x => x.UpdatedDate)
               .HasColumnName("UpdatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString())
               .IsRequired();
        }
    }
}
