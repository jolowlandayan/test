﻿using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Core.Interfaces
{
    public interface IMD_RoomsRepository : IRepository<MD_Rooms>
    {
        MD_Rooms GetRoomById(int id);
        IQueryable<MD_Rooms> SearchByRoomName(string roomName);
        IEnumerable<MD_Rooms> SearchByFloor(int floor);
        IEnumerable<MD_Rooms> SearchByMinCapacity(int capacity);

        IEnumerable<MD_Rooms> GetAllRooms();
    }
}
