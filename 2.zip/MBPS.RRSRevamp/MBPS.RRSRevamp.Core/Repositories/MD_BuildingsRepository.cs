﻿using MBPS.RRSRevamp.Core.Interfaces;
using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Repositories
{
    public class MD_BuildingsRepository : GenericRepository<MD_Buildings>, IMD_BuildingsRepository
    {
        public MD_BuildingsRepository() { }

        public MD_BuildingsRepository(DataContext context) : base(context) { }

        public MD_Buildings GetBuildingsById(int id)
        {
            return Context.MD_Buildings.FirstOrDefault(x => x.BuildingId == id);
        }
    }
}
