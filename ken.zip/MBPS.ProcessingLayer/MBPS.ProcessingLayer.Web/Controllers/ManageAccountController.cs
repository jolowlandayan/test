﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MBPS.ProcessingLayer.Web.Controllers
{
    public class ManageAccountController : Controller
    {
        // GET: ManageAccount
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AddNewAccount()
        {
            return View();
        }
    }
}