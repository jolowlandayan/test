namespace MBPS.RRSRevamp.Services.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addMinMaxCapacityColumn_20190514 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.MD_Rooms", "MinCapacity", c => c.Int(nullable: false));
            AddColumn("dbo.MD_Rooms", "MaxCapacity", c => c.Int(nullable: false));
            DropColumn("dbo.MD_Rooms", "Capacity");
        }
        
        public override void Down()
        {
            AddColumn("dbo.MD_Rooms", "Capacity", c => c.Int(nullable: false));
            DropColumn("dbo.MD_Rooms", "MaxCapacity");
            DropColumn("dbo.MD_Rooms", "MinCapacity");
        }
    }
}
