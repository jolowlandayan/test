﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MBPS.ProcessingLayer.Web.Controllers
{
    public class ManageCoreActivitiesController : Controller
    {
        // GET: ManageCoreActivities
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult ManageCoreActivities()
        {
            return View();
        }
    }
}