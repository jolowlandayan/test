namespace MBPS.RRSRevamp.Services.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class changeDataTypeForDateTime_20190516 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.MD_Rooms", "IsActive", c => c.Boolean(nullable: false, defaultValue: true));
            Sql("ALTER TABLE MD_Rooms ADD CONSTRAINT [DF_MD_Rooms_CreatedDate] DEFAULT GETDATE() FOR CreatedDate");
            Sql("ALTER TABLE MD_Rooms ADD CONSTRAINT [DF_MD_Rooms_UpdatedDate] DEFAULT GETDATE() FOR UpdatedDate");
        }
        
        public override void Down()
        {
        }
    }
}
