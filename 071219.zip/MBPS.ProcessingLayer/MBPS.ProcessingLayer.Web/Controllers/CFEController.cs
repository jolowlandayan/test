﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MBPS.ProcessingLayer.Web.Controllers
{
    public class CFEController : Controller
    {
        // GET: CFE
        public ActionResult Index()
        {
            return View();
        }
       
        public ActionResult ManageCFE()
        {
            return View();
        }
    }
}