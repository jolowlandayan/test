﻿using MBPS.RRSRevamp.Core.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.RRSRevamp.Infrastructure.Configurations
{
    public class Lkp_ReservationStatusConfiguration : EntityTypeConfiguration<Lkp_ReservationStatus>
    {
        public Lkp_ReservationStatusConfiguration()
        {
            ToTable("Lkp_ReservationStatus");
            HasKey(x => x.ReservationStatusId);

            Property(x => x.ReservationStatusId)
                .HasColumnName("ReservationStatusId")
                .HasColumnType(SqlDbType.Int.ToString())
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            Property(x => x.ReservationStatusName)
                .HasColumnName("ReservationStatusName")
                .HasColumnType(SqlDbType.VarChar.ToString())
                .HasMaxLength(128)
                .IsRequired();

            Property(x => x.ReservationStatusDescription)
                .HasColumnName("ReservationStatusDescription")
                .HasColumnType(SqlDbType.VarChar.ToString())
                .HasMaxLength(512);

            Property(x => x.CreatedBy)
               .HasColumnName("CreatedBy")
               .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.CreatedDate)
               .HasColumnName("CreatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString());

            Property(x => x.UpdatedBy)
               .HasColumnName("UpdatedBy")
               .HasColumnType(SqlDbType.Int.ToString());

            Property(x => x.UpdatedDate)
               .HasColumnName("UpdatedDate")
               .HasColumnType(SqlDbType.SmallDateTime.ToString());

        }
    }
}
