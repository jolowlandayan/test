namespace MBPS.RRSRevamp.Services.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class addColumnDefaultValues : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.TD_RoomReservation", "ApprovedBy", c => c.Int());
            AlterColumn("dbo.TD_RoomReservation", "ApprovedDate", c => c.DateTime(storeType: "smalldatetime"));

            //Default values for table Lkp_ReservationStatus
            Sql("ALTER TABLE Lkp_ReservationStatus ADD CONSTRAINT [DF_Lkp_ReservationStatus_CreatedDate] DEFAULT GETDATE() FOR CreatedDate");
            Sql("ALTER TABLE Lkp_ReservationStatus ADD CONSTRAINT [DF_Lkp_ReservationStatus_UpdatedDate] DEFAULT GETDATE() FOR UpdatedDate");

            //Default values for table MD_Buildings
            AlterColumn("dbo.MD_Buildings", "IsActive", c => c.Boolean(nullable: false, defaultValue: true));
            Sql("ALTER TABLE MD_Buildings ADD CONSTRAINT [DF_MD_Buildings_CreatedDate] DEFAULT GETDATE() FOR CreatedDate");
            Sql("ALTER TABLE MD_Buildings ADD CONSTRAINT [DF_MD_Buildings_UpdatedDate] DEFAULT GETDATE() FOR UpdatedDate");

            //Default values for table MD_Rooms_Components
            Sql("ALTER TABLE MD_Rooms_Components ADD CONSTRAINT [DF_MD_Rooms_Components_CreatedDate] DEFAULT GETDATE() FOR CreatedDate");
            Sql("ALTER TABLE MD_Rooms_Components ADD CONSTRAINT [DF_MD_Rooms_Components_UpdatedDate] DEFAULT GETDATE() FOR UpdatedDate");

            //Default values for table TD_RoomReservation            
            Sql("ALTER TABLE TD_RoomReservation ADD CONSTRAINT [DF_TD_RoomReservation_CreatedDate] DEFAULT GETDATE() FOR CreatedDate");
            Sql("ALTER TABLE TD_RoomReservation ADD CONSTRAINT [DF_TD_RoomReservation_UpdatedDate] DEFAULT GETDATE() FOR UpdatedDate");

        }
        
        public override void Down()
        {
            AlterColumn("dbo.TD_RoomReservation", "ApprovedDate", c => c.DateTime(nullable: false, storeType: "smalldatetime"));
            AlterColumn("dbo.TD_RoomReservation", "ApprovedBy", c => c.Int(nullable: false));
        }
    }
}
