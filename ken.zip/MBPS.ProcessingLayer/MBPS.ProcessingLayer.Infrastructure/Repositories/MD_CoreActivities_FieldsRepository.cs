﻿using MBPS.ProcessingLayer.Core.Interfaces;
using MBPS.ProcessingLayer.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MBPS.ProcessingLayer.Infrastructure.Repositories
{
    public class MD_CoreActivities_FieldsRepository : GenericRepository<MD_CoreActivities_Fields>, IMD_CoreActivities_FieldsRepository
    {
        public MD_CoreActivities_FieldsRepository() { }
        public MD_CoreActivities_FieldsRepository(DataContext Context) : base(Context) { }
    }
}
